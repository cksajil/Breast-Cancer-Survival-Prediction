# METABRIC Model Deployment
A repository to perform METABRIC model deployment

**Python Version**

Python 3.9.12

**Virtual Environment**

*Installing Virtual Environment*
```console
python -m pip install --user virtualenv
```
*Creating New Virtual Environment*
```console
python -m venv envname
```
*Activating Virtual Environment*
```console
source envname/bin/activate
```
*Installing Packages*
```console
python -m pip install -r requirements.txt
```

```
**Usage**
```console
python app.py 
```

**Tested on**
```console
MAC 10.14.6
```
