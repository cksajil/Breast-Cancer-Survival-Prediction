import numpy as np
from joblib import load
from sklearn import preprocessing

def final_fun_1(X_raw, best_model_path):
    #Load pretrained models
    clf = load(best_model_path)
    # encoder = load('./Pretrained/One_Hot_Encoder.joblib')
    
    #Split Numetical and Categorical Features
    numericalFeats = X_raw.select_dtypes('number').columns
    # categoricalFeats = X_raw.select_dtypes('object').columns

    numdata = X_raw[numericalFeats]
    # catdata = X_raw[categoricalFeats]
    

    # Scale Numerical Table
    # numdata_scaled = preprocessing.scale(numdata)
    # print(numdata)
    # One-hot Encode Test data
    # catendata = encoder.transform(catdata).toarray()

    # Combine Features
    # X_test = np.concatenate((numdata_scaled, catendata), axis=1)

    
    y_pred= clf.predict(numdata)
    return y_pred