#import libraries
import numpy as np
import pandas as pd
from joblib import load
from src.process import final_fun_1
from flask import Flask, request, render_template


#Initialize the flask App
app = Flask(__name__)

best_model_path = './Pretrained/Logistic_Regression.joblib'

#default page of our web-app
@app.route('/')
def home():
    return render_template('index.html')

#To use the predict button in our web-app
@app.route('/predict',methods=['POST'])
def predict():
    '''
    For rendering results on HTML GUI
    '''
    ans = ['Not Likely to Survive','Likely to Survive']
    if request.method == 'POST':
        req = request.files.get('myfile')
        if req:
            data = pd.read_csv(req,index_col=False)
            y_pred = final_fun_1(data, best_model_path)[0]

    return render_template('index.html',\
         prediction_text='{}'.format(ans[y_pred]))

if __name__ == "__main__":
    app.run(debug=True)